//
//  CurrencyManager.swift
//  Deep Linking Sample
//
//  Created by Kevin Macaulay on 4/19/22.
//  Copyright © 2022 Apriva. All rights reserved.
//

import Foundation

class CurrencyManager {
    static let shared = CurrencyManager()

    /// Used to format currency values with the currency symbol. For example: $12,345.67
    let currencyFormatter: NumberFormatter = NumberFormatter()

    /// The maximum digit length allowed for a transaction
    let maxTransactionDigits = 7

    /// The number of  digits before the decimal separator.
    var currencyCharacteristic: Int {
        return maxTransactionDigits - currencyFormatter.maximumFractionDigits
    }

    /// The number of significant digits after the decimal separator.
    var currencyScale: Int {
        return currencyFormatter.maximumFractionDigits
    }

    /// The maximum amount allowed for a transaction
    var maxTransactionAmount: Money {
        guard let minorUnits = Int(String(repeating: "9", count: maxTransactionDigits)) else { return .zero() }
        return Money(minorUnits: minorUnits)
    }

    /// Defines the rounding mode and scale of decimal numbers based on the current currency code.
    var decimalNumberBehavior: NSDecimalNumberBehaviors {
        return NSDecimalNumberHandler(
            roundingMode: .plain,
            scale: Int16(currencyScale),
            raiseOnExactness: true,
            raiseOnOverflow: true,
            raiseOnUnderflow: true,
            raiseOnDivideByZero: true
        )
    }

    // MARK: - Initialization

    init() {
        currencyFormatter.numberStyle = .currency
        currencyFormatter.generatesDecimalNumbers = true
        currencyFormatter.locale = .current
    }
}
