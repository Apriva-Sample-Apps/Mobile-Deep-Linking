//
//  Money.swift
//  Deep Linking Sample
//
//  Created by Kevin Macaulay on 4/19/22.
//  Copyright © 2022 Apriva. All rights reserved.
//

import Foundation

class Money {
    let value: NSDecimalNumber

    /// The "minor unit" of a currency is its smallest unit (cents, pence, yen, etc.)
    var minorUnits: Int {
        let scale = CurrencyManager.shared.currencyScale
        let behavior = CurrencyManager.shared.decimalNumberBehavior
        return value.multiplying(byPowerOf10: Int16(scale), withBehavior: behavior).intValue
    }

    // MARK: - Initializers

    init(decimalNumber: NSDecimalNumber) {
        value = decimalNumber.rounding(accordingToBehavior: CurrencyManager.shared.decimalNumberBehavior)
    }

    init(minorUnits: Int) {
        let scale = CurrencyManager.shared.currencyScale
        let behavior = CurrencyManager.shared.decimalNumberBehavior
        value = NSDecimalNumber(value: minorUnits as Int).multiplying(byPowerOf10: Int16(scale * -1), withBehavior: behavior)
    }

    // MARK: Class Initializers

    class func zero() -> Money {
        return Money(decimalNumber: NSDecimalNumber.zero)
    }

    // MARK: - Currency Formatted String Methods

    /// Returns a formatted string using the specified currency code and the device's current locale with the currency symbol.
    func currencyString() -> String? {
        return value.currencyString()
    }

    // MARK: - Compare Methods

    func isGreaterThan(_ money: Money) -> Bool {
        return value.isGreaterThanDecimalNumber(money.value)
    }
}

extension NSNumber {
    var money: Money {
        return Money(decimalNumber: self.decimalNumber)
    }

    var decimalNumber: NSDecimalNumber {
        return NSDecimalNumber(decimal: self.decimalValue)
    }

    /// Returns a formatted string using the specified currency code and the device's current locale with the currency symbol.
    func currencyString() -> String? {
        return CurrencyManager.shared.currencyFormatter.string(from: self)
    }
}

extension NSDecimalNumber {
    func isGreaterThanDecimalNumber(_ decimalNumber: NSDecimalNumber) -> Bool {
        return compare(decimalNumber) == .orderedDescending
    }
}
