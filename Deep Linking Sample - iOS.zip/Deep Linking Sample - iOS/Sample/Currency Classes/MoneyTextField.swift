//
//  MoneyTextField.swift
//  Deep Linking Sample
//
//  Created by Kevin Macaulay on 4/19/22.
//  Copyright © 2022 Apriva. All rights reserved.
//

import UIKit

class MoneyTextField: UITextField {
    var maximumAmount = CurrencyManager.shared.maxTransactionAmount

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        delegate = self
        textAlignment = .right
        placeholder = Money.zero().currencyString()
    }

    /// Returns the numeric money value of the text field text.
    var money: Money {
        guard let text = text else { return Money.zero() }
        return CurrencyManager.shared.currencyFormatter.number(from: text)?.money ?? Money.zero()
    }
}

extension MoneyTextField: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // first, replace the characters in the string
        guard let textField = textField as? MoneyTextField, let text = text else { return false }
        let nsstring = NSString(string: text)
        let replacedString = nsstring.replacingCharacters(in: range, with: string)

        // remove any non-numeric characters from the string to remove any decimal or grouping separators or currency symbols
        let numericString = replacedString.components(separatedBy: CharacterSet.decimalDigits.inverted).joined(separator: "")

        // convert the numeric string to a minor units value, and initialize a money object
        guard let minorUnits = Int(numericString) else { return false }
        let money = Money(minorUnits: minorUnits)

        // if amount is larger than the max amount allowed by the field, return false
        if money.isGreaterThan(maximumAmount) {
            return false
        }

        // everything looks good, so replace the text string with the currency string of the money object
        self.text = money.currencyString()

        // post the text field did change notification before returning false, since we are going to reformat the string
        NotificationCenter.default.post(name: UITextField.textDidChangeNotification, object: self)

        if let amountString = textField.text,
            let lastIndex = amountString.lastIndex(where: { $0.isNumber }) {
            let cursorOffset = amountString.distance(from: amountString.startIndex, to: lastIndex) + 1

            if let cursorPosition = textField.position(from: textField.beginningOfDocument, offset: cursorOffset) {
                textField.selectedTextRange = textField.textRange(from: cursorPosition, to: cursorPosition)
            }
        }

        return false
    }
}
