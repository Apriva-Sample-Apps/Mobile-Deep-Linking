//
//  ViewController.swift
//  Deep Linking Sample
//
//  Created by Kevin Macaulay on 4/19/22.
//  Copyright © 2022 Apriva. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var moneyTextField: MoneyTextField!

    // MARK: - IBActions

    @IBAction func payNowTapped() {
        // The amount should be represented in minor units. For example, $1.23 would be represented as 123 in minor units
        let amount = moneyTextField.money.minorUnits

        // TODO: Replace the URL host with the Merchant Portal URL host for the AprivaPay brand that you are integrating with
        let urlHost = "<BRAND_URL_HOST>" // Ex: "merchant.apriva.com"

        guard let url = URL(string: "https://\(urlHost)/dl/sale?amount=\(amount)"), amount > 0 else {
            print("Unable to open URL: https://\(urlHost)/dl/sale?amount=\(amount)")
            return
        }

        UIApplication.shared.open(url) { success in
            if success {
                self.moneyTextField.text = nil
            } else {
                print("Unable to open URL: \(url)")
            }
        }
    }
}
