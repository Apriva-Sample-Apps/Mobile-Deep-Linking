package com.apriva.mobile.testdeeplinking

import androidx.annotation.MainThread
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import org.joda.money.Money

class MainActivityViewModel : ViewModel() {

    private val _state = MutableStateFlow(MainActivityState())
    val state = _state.asStateFlow()

    @MainThread
    fun onAmountUpdated(amount: Money) {
        _state.update { it.copy(amount = amount) }
    }
}