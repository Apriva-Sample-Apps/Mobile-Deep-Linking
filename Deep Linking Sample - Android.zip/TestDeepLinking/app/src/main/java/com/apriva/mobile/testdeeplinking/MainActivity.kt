package com.apriva.mobile.testdeeplinking

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.apriva.mobile.testdeeplinking.databinding.ActivityMainBinding
import kotlinx.coroutines.launch
import org.joda.money.Money


class MainActivity : AppCompatActivity(R.layout.activity_main) {

    private val binding by viewBinding(ActivityMainBinding::bind)

    private val viewModel by viewModels<MainActivityViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding.amountInput.moneyUpdateListener = { newAmount ->
            viewModel.onAmountUpdated(newAmount)
        }

        binding.launch.setOnClickListener {
            val amount = viewModel.state.value.amount
            launchDeepLink(amount.amountMinorLong)
        }


        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collect{ state ->
                    if (state.amount != binding.amountInput.money){
                        binding.amountInput.money = state.amount
                    }
                }
            }
        }
    }

    private fun launchDeepLink(amount: Long){
        //////////////////////////
        //        TODO          //
        //////////////////////////
        //  ADD URL HOST HERE   //
        //////////////////////////
        val urlHost = "<BRAND_URL_HOST>" // Ex: "merchant.apriva.com"
        val uri = Uri.parse("https://$urlHost/dl/sale?amount=$amount")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.addCategory(Intent.CATEGORY_DEFAULT) // optional
        intent.addCategory(Intent.CATEGORY_BROWSABLE) // optional

        /*
         * Note that if the context is not android.app.Activity Context,
         * then the Intent must include the Intent.FLAG_ACTIVITY_NEW_TASK launch flag
         */
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

        this.startActivity(intent)
    }
}