package com.apriva.mobile.testdeeplinking

import org.joda.money.CurrencyUnit
import org.joda.money.Money
import org.joda.money.format.MoneyAmountStyle
import org.joda.money.format.MoneyFormatter
import org.joda.money.format.MoneyFormatterBuilder
import java.util.*
import kotlin.collections.HashMap

private val moneyFormatterMap = HashMap<FormatterConfig, MoneyFormatter>()

private data class FormatterConfig(val local: Locale, val currencyUnit: CurrencyUnit)

fun Money.toFormattedString(): String {

    val currentLocale = Locale.getDefault()
    val config = FormatterConfig(local = currentLocale, currencyUnit = currencyUnit)

    if (!moneyFormatterMap.containsKey(config)) {

        val newFormatter = if (currencyUnit == CurrencyUnit.CAD && currentLocale == Locale.CANADA_FRENCH){
            MoneyFormatterBuilder()
                .appendAmount(MoneyAmountStyle.ASCII_DECIMAL_COMMA_GROUP3_DOT)
                .appendLiteral(" $")
                .toFormatter()
        } else if (currencyUnit == CurrencyUnit.GBP){
            MoneyFormatterBuilder()
                .appendLiteral(currencyUnit.symbol)
                .appendAmount(MoneyAmountStyle.ASCII_DECIMAL_POINT_GROUP3_COMMA)
                .toFormatter()
        } else {
            MoneyFormatterBuilder()
                .appendLiteral(currencyUnit.symbol)
                .appendAmount(MoneyAmountStyle.ASCII_DECIMAL_POINT_GROUP3_COMMA)
                .toFormatter()
                .withLocale(currentLocale)
        }

        moneyFormatterMap[config] = newFormatter
    }


    val formatter = moneyFormatterMap[config]!!

    return formatter.print(this)
}