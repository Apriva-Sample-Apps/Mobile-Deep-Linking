package com.apriva.mobile.testdeeplinking

import org.joda.money.CurrencyUnit
import org.joda.money.Money

data class MainActivityState(
    val amount: Money = Money.zero(CurrencyUnit.USD)
)